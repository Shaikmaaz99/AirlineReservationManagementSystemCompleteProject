import { Component, OnInit } from '@angular/core';
import { Flight } from '../../Model/Flight';
import { FlightService } from '../../Services/flight.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addflight',
  standalone: false,
  templateUrl: './addflight.component.html',
  styleUrl: './addflight.component.css'
})
export class AddflightComponent implements OnInit {
  constructor(private flightService:FlightService,private router:Router){}
  flight= new Flight();
  countries:any;
  ngOnInit(): void {
    this.flight.flightAirlineCountry='';
    this.flightService.getAllCountries().subscribe(
      (data: any) => {
        console.log(data); // Check what data looks like
        this.countries = data;
      }
      );
      }
  
  
  
  addFlight(){
    this.flightService.addFlight(this.flight).subscribe(
      (response:any)=>{
        this.flight=response;
        alert('✅ Flight added successfully!');
      this.router.navigate(['manageflight']);
      }
    )
  }
  preventNegativeInput(event: KeyboardEvent): void {
    // Allow only numeric values
    if (event.key === '-' || event.key === '+' || event.key === 'e') {
      event.preventDefault();
    }
  } 
  

}
