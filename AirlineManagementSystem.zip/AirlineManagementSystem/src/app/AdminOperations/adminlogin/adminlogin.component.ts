import { Component, OnInit } from '@angular/core';
import { LoginvalidationService } from '../../Services/loginvalidation.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  standalone: false,
  templateUrl: './adminlogin.component.html',
  styleUrl: './adminlogin.component.css'
})
export class AdminloginComponent implements OnInit{
  constructor(private loginvalidationService:LoginvalidationService,private router:Router){}
  username:any;
  password:any;
  invalidlogic=false;
  name='';
  ngOnInit(): void {
    
  }
  adminLogin(){
    if(this.loginvalidationService.adminLoginValidation(this.username,this.password)){
      this.invalidlogic=false;
      this.name=this.username;
      this.router.navigate(['adminwelcome',this.name]);

    }
    else{
      alert("INVALID LOGIN")
      this.invalidlogic=true;
  }

  }

}
