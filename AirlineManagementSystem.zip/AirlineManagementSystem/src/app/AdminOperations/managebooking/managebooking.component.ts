import { Component, OnInit } from '@angular/core';
import { PassengerService } from '../../Services/passenger.service';
import { Passenger } from '../../Model/Passenger';

@Component({
  selector: 'app-managebooking',
  standalone: false,
  templateUrl: './managebooking.component.html',
  styleUrl: './managebooking.component.css'
})
export class ManagebookingComponent implements OnInit{
  passengers: Passenger[] = [];  // The original list of passengers
  filteredPassengers: Passenger[] = [];  // List that will be shown in the table
  p: number = 1; // Current page for pagination
  count: number = 5; // Items per page
  searchTerm: string = ''; // Search term

  constructor(private passengerService: PassengerService) { }

  ngOnInit() {
    this.getPassengers(); // Fetch passengers when the component is initialized
  }

  // Fetch passengers from the service
  getPassengers() {
    this.passengerService.getAllPasenger().subscribe(
      (data:any)=> {
      this.passengers = data; // Set the passengers data
      this.filteredPassengers = this.passengers; // Initialize filteredPassengers with all passengers initially
    });
  }

  // Filter passengers based on search term
  onSearch() {
    if (this.searchTerm.trim()) {
      this.passengerService.searchPassenger(this.searchTerm).subscribe(
        (response: any) => {
          console.log('Search Results:', response);
          this.passengers = response;  // Store the response in the passengers array
        },
        (error) => {
          console.error('Error fetching passengers', error);
        }
      );
    } else {
      // Handle empty search term (optional)
      this.passengers = [];
    }
  }
  
}
