import { Component, OnInit } from '@angular/core';
import { UserService } from '../../Services/user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-updateusers',
  standalone: false,
  templateUrl: './updateusers.component.html',
  styleUrl: './updateusers.component.css'
})
export class UpdateusersComponent implements OnInit{
  userId:any;
  userObject:any;
  constructor(private userService:UserService,private activateRoute:ActivatedRoute,private router:Router){}

  ngOnInit(): void {
    this.userId=this.activateRoute.snapshot.params['userId'];
    this.userService.getUserbyId(this.userId).subscribe(
      (response)=>
      {
        this.userObject=response;
      }
    )
    
  }
  UpdateuserDetails(){
    return this.userService.updateUserDetails(this.userId,this.userObject).subscribe(
      (response:any)=>
      {
        alert("updated successfully");
        this.router.navigate(['viewusers']);
  
      }
    )
  }
  preventNegativeInput(event: KeyboardEvent) {
    if (event.key === '-' || event.key === 'e') {
      event.preventDefault();
    }
  }
  

}
