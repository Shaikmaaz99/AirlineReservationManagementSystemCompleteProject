import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewflightreportsComponent } from './viewflightreports.component';

describe('ViewflightreportsComponent', () => {
  let component: ViewflightreportsComponent;
  let fixture: ComponentFixture<ViewflightreportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ViewflightreportsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewflightreportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
