import { Component, OnInit } from '@angular/core';
import { FlightService } from '../../Services/flight.service';

@Component({
  selector: 'app-viewflightreports',
  standalone: false,
  templateUrl: './viewflightreports.component.html',
  styleUrl: './viewflightreports.component.css'
})
export class ViewflightreportsComponent implements OnInit{
  constructor(private flightservice:FlightService){}
  flights:any;
  p:number=1;
  count:number=5;
  ngOnInit(): void {
    this.loadflightreports();
  }
  loadflightreports(){
    this.flightservice.getAllflights().subscribe(
      (data:any) => {
        this.flights = data;
      },
      (error) => {
        console.error('Error loading passengers', error);
      }
    );
  }

}
