import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SeatService } from '../../Services/seat.service';

@Component({
  selector: 'app-viewseatsbyflight-id',
  standalone: false,
  templateUrl: './viewseatsbyflight-id.component.html',
  styleUrl: './viewseatsbyflight-id.component.css'
})
export class ViewseatsbyflightIdComponent implements OnInit {
  flightId!: number;
  seatList: any[] = [];
  seats: any;

  constructor(private route: ActivatedRoute, private seatService: SeatService, private router: Router) {}

  ngOnInit(): void {
    this.flightId = Number(this.route.snapshot.paramMap.get('flightId'));
    this.getSeats();
  }

  getSeats(): void {
    this.seatService.getAllSeatsByFlightId(this.flightId).subscribe(
      (response: any) => {
        this.seatList = response;
      },
      (error) => {
        console.error(error);
        alert('❌ Failed to fetch seats.');
      }
    );
  }

  updateSeat(seatId: any): void {
    // Only allow update if the seat is available
    const seat = this.seatList.find(s => s.seatId === seatId);
    if (seat && seat.status === 'Available') {
      this.router.navigate(['updateseat', this.flightId, seatId]);
    } else {
      alert("You cannot update a seat that is already booked or on the waiting list.");
    }
  }

  deleteSeat(seatId: any): void {
    // Only allow delete if the seat is available
    const seat = this.seatList.find(s => s.seatId === seatId);
    if (seat && seat.status === 'Available') {
      this.seatService.deleteSeatByFlightId(this.flightId, seatId).subscribe(
        (response: any) => {
          this.seatList = response;
          alert("Seat deleted successfully!");
        },
        (error) => {
          console.error(error);
          alert('❌ Failed to delete seat.');
        }
      );
    } else {
      alert("You cannot delete a seat that is already booked or on the waiting list.");
    }
  }
}
