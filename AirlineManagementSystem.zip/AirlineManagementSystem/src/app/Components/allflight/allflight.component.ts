import { Component, OnInit } from '@angular/core';
import { FlightService } from '../../Services/flight.service';
import { Flight } from '../../Model/Flight';
import { Router } from '@angular/router';

@Component({
  selector: 'app-allflight',
  standalone: false,
  templateUrl: './allflight.component.html',
  styleUrl: './allflight.component.css'
})
export class AllflightComponent implements OnInit {
    flights: any[] = [];
    flight=new Flight();
  p:number=1;
  count:number=3;
  currentDate: Date = new Date();
    constructor(private flightService:FlightService,private router:Router) {}
    ngOnInit(): void {
      this.flightService.getFlightsWithAvailableSeats().subscribe(
        (data: any) => {
          this.flights = data;
    
          // Set currentDate to compare with flight departure time
          this.currentDate = new Date();
          this.currentDate.setHours(0, 0, 0, 0); // Set current date to midnight for comparison
    
          // Filter flights based on currentDate (removing past flights)
          this.flights = this.flights.filter(flight => {
            const departureDate = new Date(flight.departureTime); // Convert string to Date
            return departureDate >= this.currentDate && flight.totalSeats > 0;
          });
        },
        (error) => {
          console.error('Error fetching flights', error);
        }
      );
    }
    
    
    
    
    bookFlight(flightId:any){
      this.router.navigate(['selectflight',flightId])
    }

}
