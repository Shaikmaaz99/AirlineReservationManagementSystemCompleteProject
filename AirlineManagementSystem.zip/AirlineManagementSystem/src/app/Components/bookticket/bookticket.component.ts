import { Component, OnInit } from '@angular/core';
import { Flight } from '../../Model/Flight';
import { Router } from '@angular/router';
import { FlightService } from '../../Services/flight.service';

@Component({
  selector: 'app-bookticket',
  standalone: false,
  templateUrl: './bookticket.component.html',
  styleUrl: './bookticket.component.css'
})
export class BookticketComponent implements OnInit{
  constructor(private router:Router,private flightService:FlightService){}
  flight=new Flight();
  flights: Flight[] = [];
  date:any;
  destination:any;
  departure:any;
  noFlightsFound: boolean = false;
  ngOnInit(): void {
    
  }
  selectFlight(flight:any){
    this.router.navigate(['selectflight',flight.flightId])
  }
  
  searchFlights() {
    this.flightService.searchFlightByFromAndTo(this.departure, this.destination).subscribe(
      (response: any) => {
        const now = new Date();
  
        // Filter only today's and future flights
        this.flights = response.filter((flight: any) => {
          const departure = new Date(flight.departureTime);
          return departure >= now;
        });
  
        this.noFlightsFound = this.flights.length === 0;
      },
      (error) => {
        console.error('Error fetching flights:', error);
        if (error.status === 404) {
          this.flights = [];
          this.noFlightsFound = true;
        }
      }
    );
  }
  
  getFlightDuration(departureTime: string, arrivalTime: string): string {
    const dep = new Date(departureTime);
    const arr = new Date(arrivalTime);
    const durationMs = arr.getTime() - dep.getTime();
  
    const hours = Math.floor(durationMs / (1000 * 60 * 60));
    const minutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}h ${minutes}m`;
  }
  
}
