import { Component, OnInit } from '@angular/core';
import { UserService } from '../../Services/user.service';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  standalone: false,
  templateUrl: './logout.component.html',
  styleUrl: './logout.component.css'
})
export class LogoutComponent implements OnInit{
  constructor(private userService:UserService,private router:Router){}
  ngOnInit(): void {
    alert("YOU DECIDED TO LOGOUT")
    this.userService.logout();
    this.router.navigate(['login'])
  }

}
