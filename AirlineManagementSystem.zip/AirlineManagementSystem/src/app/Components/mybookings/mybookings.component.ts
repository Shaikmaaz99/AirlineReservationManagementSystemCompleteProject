import { Component, OnInit } from '@angular/core';
import { ReservationService } from '../../Services/reservation.service';
import { Booking } from '../../Model/Booking';

@Component({
  selector: 'app-mybookings',
  standalone: false,
  templateUrl: './mybookings.component.html',
  styleUrl: './mybookings.component.css'
})
export class MybookingsComponent implements OnInit{
  bookings: any; // Now booking is typed as an array of Booking objects
  userId!: number;
  p: number = 1;
  count: number = 1;
  currentDate: Date = new Date();

  constructor(private reservationService: ReservationService) {}

  ngOnInit(): void {
    //this.bookings.reservationStatus = this.bookings.reservationStatus.toUpperCase();

    this.userId = Number(sessionStorage.getItem('userId')); // auto fetch logged-in userId
    if (this.userId) {
      this.getBookings();
    }
  }

  getBookings(): void {
    this.reservationService.getTheBookingDetailsByUserId(this.userId).subscribe(
      (data: any) => {
        console.log('Booking Data:', data);  // Verify if status is included in the response
        this.bookings = data.map((booking: any) => ({
          ...booking,
          reservationStatus: booking.reservationStatus || 'UNKNOWN' // Default to 'UNKNOWN' if not set
        }));
      },
      (error) => {
        console.error('Error fetching bookings:', error);
      }
    );
  }
  
  
     
  canCancel(departureTime: string | Date): boolean {
    const departure = new Date(departureTime);
    const now = new Date();
  
    // Calculate the time difference in milliseconds
    const diffInMs = departure.getTime() - now.getTime();
  
    // Convert to hours
    const diffInHours = diffInMs / (1000 * 60 * 60);
  
    // Return true if more than 24 hours remain
    return diffInHours >= 24;
  }

  canCompleteTrip(departureTime: string | Date, arrivalTime: string | Date): boolean {
    const departure = new Date(departureTime);
    const arrival = new Date(arrivalTime);
    const now = new Date();
  
    // If both departure and arrival times are in the past, then the trip is completed
    return departure < now && arrival < now;
  }

  cancelBooking(reservationNumber: string): void {
    const confirmCancel = confirm('❓ Are you sure you want to cancel this booking?');
  
    if (!confirmCancel) return;
  
    this.reservationService.cancleReservation(reservationNumber).subscribe({
      next: (response: any) => {
        console.log('✅ Booking cancelled:', response);
        alert(response?.message || '✅ Booking cancelled successfully!');
        this.getBookings(); // Refresh the booking list after cancellation to update the status
      },
      error: (error: any) => {
        console.error('❌ Error cancelling booking:', error);
        alert('⚠️ Failed to cancel the booking. Please try again later.');
      }
    });
  }
  
  
  
    
} 
