import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment',
  standalone: false,
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.css'
})
export class PaymentComponent implements OnInit {
  totalAmount: number = 0;  // You will set this value dynamically
  selectedPaymentMethod: string = '';  // Store selected payment method
  finalPassengers: any[] = [];  // List of passengers
  flightDetails: any = {};  // Flight details (e.g., flight name, number)

  ngOnInit(): void {
    // Initialize total amount and passenger details if needed
    this.totalAmount = this.calculateTotalAmount();
    // Set flight details if necessary (could be passed via route or service)
  }

  calculateTotalAmount(): number {
    return this.finalPassengers.reduce((sum, p) => sum + (p.seatPrice || 0), 0);
  }

  processPayment() {
    if (!this.selectedPaymentMethod) {
      alert('Please select a payment method');
      return;
    }

    // Call the payment API or navigate to the next step
    console.log(`Processing payment of ₹${this.totalAmount} using ${this.selectedPaymentMethod}`);
    // Navigate or handle the payment logic here...
  }

}
