import { Component, OnInit } from '@angular/core';
import { UserService } from '../../Services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FlightService } from '../../Services/flight.service';
import { User } from '../../Model/User';
import { PassengerService } from '../../Services/passenger.service';
import { Passenger } from '../../Model/Passenger';
import { Flight } from '../../Model/Flight';
import { SeatService } from '../../Services/seat.service';
import { Seat } from '../../Model/Seat';
import { BankserverService } from '../../Services/bankserver.service';

@Component({
  selector: 'app-selectflight',
  standalone: false,
  templateUrl: './selectflight.component.html',
  styleUrl: './selectflight.component.css'
})
export class SelectflightComponent implements OnInit {
  user: any = {};
  flight: any;
  userId: any;
  seatSelection: any;
  flightId: any;
  isEditMode: boolean = false;
  userCategory: string = '';
  seatList: Seat[] = [];

  isUserAlsoPassenger: boolean = false;
  selectedPassengerIndex: number = 0;
  passengers: Passenger[] = [];
  userSeatNumber: string = '';
  selectedSeatNumbers: string[] = [];
  currentSelector: 'user' | 'passenger' = 'user';
  selectedSeats: Set<number> = new Set();
  selectedPassenger: Passenger = new Passenger();
  paymentId:any;

  totalAmount: number = 0;
  showPaymentSection: boolean = false;
  isUpiValid: boolean = true;
  b : any;
  a: any;
  upicheck: any;
  c : any;
  paymentMethod: any; // Tracks the selected payment method
  creditCardNumber: any;
  debitCardNumber: any;
  
  upiId: any;
  cardNumber: any;
  cardExpiry: any;
  cvv: any;
  constructor(
    private userService: UserService,
    private router: Router,
    private route: ActivatedRoute,
    private flightService: FlightService,
    private passengerService: PassengerService,
    private seatService: SeatService,
    private bankService:BankserverService
  ) {}

  ngOnInit(): void {
    this.flightId = this.route.snapshot.paramMap.get('flightId');
    this.userId = sessionStorage.getItem('userId');

    this.userService.getUserbyId(this.userId).subscribe(
      (response: any) => this.user = response,
      error => console.error("Error fetching user details", error)
    );

    this.flightService.getFlightById(this.flightId).subscribe(
      (response: any) => {
        this.flight = response;
        this.loadSeats(this.flightId);
      },
      error => console.error("Error fetching flight details", error)
    );
  }

  loadSeats(flightId: number) {
    this.seatService.getAllSeatsByFlightId(flightId).subscribe(
      (response: any) => this.seatList = response,
      error => console.error("Error loading seats", error)
    );
  }
  getRows(seatList: Seat[]): Seat[][] {
    const rows: Seat[][] = [];
    let row: Seat[] = [];
  
    seatList.forEach((seat, index) => {
      row.push(seat);
  
      // Assuming that every 6 seats represent a row. Adjust the number based on your seat configuration.
      if ((index + 1) % 6 === 0) {
        rows.push(row);
        row = [];
      }
    });
  
    // Push remaining seats if any
    if (row.length) {
      rows.push(row);
    }
  
    return rows;
  }
  

  isSeatAlreadySelected(seatNumber: string, currentIndex: number): boolean {
    // Check if selected by user
    if (this.isUserAlsoPassenger && this.userSeatNumber === seatNumber) return true;

    // Check if selected by other passengers
    return this.passengers.some((passenger, index) => passenger.pSeatNumber === seatNumber && index !== currentIndex);
  }
  isPassengerFormValid(passenger: Passenger): boolean {
    // Check if all required fields are filled
    return passenger.pFirstName && passenger.pLastName && passenger.pEmail && passenger.pMobileNo && passenger.pPassportNo ? true : false;
  }
  
  
  removePassenger(index: number): void {
    this.passengers.splice(index, 1);
    console.log('Passenger removed at index:', index);
  }

  
  selectSeat(seat: Seat) {
    // If the seat is already booked, show an alert and return
    if (seat.status === 'booked') {
      alert("This seat is already booked. Please select another seat.");
      return;
    }
  
    const seatNumber = seat.seatNumber;
  
    // Check if the seat is already selected by another passenger (including the user)
    const seatTaken = this.passengers.some(p => p.pSeatNumber === seatNumber);
    const isUserSeat = this.userSeatNumber === seatNumber;
  
    if (seatTaken || isUserSeat) {
      alert("Seat already selected by another passenger.");
      return;
    }
  
    // Check if the user is selecting a seat for themselves
    if (this.currentSelector === 'user') {
      this.selectSeatForUser(seatNumber);
    } 
    // Check if it's a passenger (not the user) selecting a seat
    else if (this.currentSelector === 'passenger') {
      // Ensure selectedPassengerIndex is defined and valid
      if (this.selectedPassengerIndex >= 0 && this.selectedPassengerIndex < this.passengers.length) {
        this.selectSeatForPassenger(this.selectedPassengerIndex, seatNumber);
      } else {
        alert("Please select a valid passenger.");
      }
    }
  }
  isFormValid(): boolean {
    // Check if the user has selected a seat
    const isUserSeatSelected = !!this.userSeatNumber;
  
    // Check if all passengers have filled required details AND selected a seat
    const areAllPassengersValid = this.passengers.every(passenger =>
      this.isPassengerFormValid(passenger) && !!passenger.pSeatNumber
    );
  
    // Return true only if both user and all passengers are valid
    return isUserSeatSelected && areAllPassengersValid;
  }
  
  

isSeatSelected(seatNumber: string): boolean {
  // Check if the seat is selected by any additional passengers
  const selectedByPassengers = this.passengers.some(p => p.pSeatNumber === seatNumber);

  // Check if the seat is selected by the logged-in user (if applicable)
  const selectedByUser = this.isUserAlsoPassenger && this.userSeatNumber === seatNumber;

  return selectedByPassengers || selectedByUser;
}


  // For user (self as passenger)
  selectSeatForUser(seatNumber: string) {
    this.userSeatNumber = seatNumber;
  
    // Update seat status to 'selected'
    const seatObject = {
      seatNumber: seatNumber,
      status: 'selected'  // Seat is selected but not yet booked
    };
  
    // Update seat status in the backend
    this.seatService.updateSeatStatusbySeatNumberofFlight(seatNumber, this.flightId, seatObject).subscribe({
      next: (response) => {
        console.log('Seat selected for user successfully:', seatNumber);
  
        // Update the seat status locally
        const seatIndex = this.seatList.findIndex(seat => seat.seatNumber === seatNumber);
        if (seatIndex !== -1) {
          this.seatList[seatIndex].status = 'selected';
        }
      },
      error: (err) => {
        console.error('Error updating seat status for user', err);
        alert('An error occurred while selecting the seat. Please try again.');
      }
    });
  }
  

  // For passengers (when the user is not also a passenger)
  selectedSeatsPerPassenger: { [index: number]: string } = {};

  selectSeatForPassenger(index: number, seatNumber: string) {
    // Set the seat number for the selected passenger
    this.passengers[index].pSeatNumber = seatNumber;
  
    // Update seat status to 'selected' for the passenger
    const seatObject = {
      seatNumber: seatNumber,
      status: 'selected'  // Seat is selected but not yet booked
    };
  
    // Update seat status in the backend
    this.seatService.updateSeatStatusbySeatNumberofFlight(seatNumber, this.flightId, seatObject).subscribe({
      next: (response) => {
        console.log('Seat selected for passenger successfully:', seatNumber);
      },
      error: (err) => {
        console.error('Error updating seat status for passenger', err);
        alert('An error occurred while selecting the seat. Please try again.');
      }
    });
  }
  
  

  isSeatSelectedForPassenger(seatNumber: string, passengerIndex: number): boolean {
    return this.selectedSeatsPerPassenger[passengerIndex] === seatNumber;
  }
  

  setSelectedPassenger(index: number) {
    this.selectedPassengerIndex = index;
    this.selectedPassenger = this.passengers[this.selectedPassengerIndex] || { pFirstName: '', pLastName: '', pEmail: '', pMobileNo: '', pPassportNo: '' };
  }

  toggleEdit() {
    this.isEditMode = !this.isEditMode;//this.isEditMode=!false
  }

  getFlightDuration(departureTime: string, arrivalTime: string): string {
    const dep = new Date(departureTime);
    const arr = new Date(arrivalTime);
    const durationMs = arr.getTime() - dep.getTime();
    const hours = Math.floor(durationMs / (1000 * 60 * 60));
    const minutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  }

  updateUser() {
    this.userService.updateUserDetails(this.userId, this.user).subscribe(
      (response: any) => {
        alert("Updated successfully");
        this.isEditMode = false;
        this.router.navigate(['selectflight']);
      }
    );
  }

  classifyUserCategory() {
    if (this.user.age != null) {
      if (this.user.age < 12) {
        this.userCategory = 'Child';
      } else if (this.user.age >= 12 && this.user.age < 18) {
        this.userCategory = 'Teenager';
      } else {
        this.userCategory = 'Adult';
      }
    } else {
      this.userCategory = '';
    }
  }

  sanitizeMobile() {
    if (this.user.userMobileNo) {
      this.user.userMobileNo = this.user.userMobileNo.replace(/[^6-9]/g, '').slice(0, 10);
    }
  }

  sanitizePassport() {
    if (this.user.userPassportNo) {
      this.user.userPassportNo = this.user.userPassportNo.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 9);
    }
  }

  addNewPassenger(): void {
  
    // Create new passenger
    const newPassenger = new Passenger();
    newPassenger.pSeatNumber = this.selectedSeatsPerPassenger[this.passengers.length];
    this.passengers.push(newPassenger);
  
    // Clear the selected seat for the next passenger
    delete this.selectedSeatsPerPassenger[this.passengers.length];
  }
 
  
  
  blockExtraDigits(event: KeyboardEvent, maxLength: number): void {
    const input = event.target as HTMLInputElement;
    const isNumber = /^[0-9]$/.test(event.key);
    if (!isNumber || input.value.length >= maxLength) {
      event.preventDefault();
    }
  }

  blockExtraChars(event: KeyboardEvent, maxLength: number): void {
    const input = event.target as HTMLInputElement;
    const isAlphaNum = /^[A-Z0-9]$/.test(event.key.toUpperCase());
    if (!isAlphaNum || input.value.length >= maxLength) {
      event.preventDefault();
    }
  }

 


//payment details 




  
 

  submitPassengers(paymentId: string) {
    const finalPassengers = [...this.passengers];
  
    if (this.isUserAlsoPassenger) {
      const userAsPassenger = new Passenger();
      userAsPassenger.pFirstName = this.user.userFirstName;
      userAsPassenger.pLastName = this.user.userLastName;
      userAsPassenger.pEmail = this.user.userEmail;
      userAsPassenger.pMobileNo = this.user.userMobileNo;
      userAsPassenger.pPassportNo = this.user.userPassportNo;
      userAsPassenger.pGender = this.user.userGender;
      userAsPassenger.pAge = this.user.userAge;
      userAsPassenger.pSeatNumber = this.userSeatNumber;
      userAsPassenger.user = this.user;
      userAsPassenger.pflightId = this.flightId;
      userAsPassenger.pPaymentId = paymentId;
  
      finalPassengers.push(userAsPassenger);
    }
  
    if (finalPassengers.length === 0) {
      alert("Please add at least one passenger or select yourself as a passenger.");
      return;
    }
  
    for (let i = 0; i < finalPassengers.length; i++) {
      const p = finalPassengers[i];
      if (
        !p.pFirstName?.trim() ||
        !p.pLastName?.trim() ||
        !p.pEmail?.trim() ||
        !p.pMobileNo?.trim() ||
        !p.pPassportNo?.trim() ||
        !p.pGender?.trim() ||
        p.pAge <= 0 ||
        !p.pSeatNumber?.trim()
      ) {
        alert(`Passenger ${i + 1} has missing details or no seat selected.`);
        return;
      }
  
      p.pflightId = this.flightId;
      p.pPaymentId = paymentId; // ✅ Add payment ID here
    }
  
    console.log("Submitting passengers with paymentId:", finalPassengers);
  
    this.passengerService.addPassengersToUser(this.userId, this.flightId, finalPassengers).subscribe({
      next: (res) => {
        alert("Passengers added successfully!");
        this.router.navigate(['successful']);
      },
      error: err => {
        console.error("Failed to save passengers", err);
        alert("Something went wrong while saving passengers.");
      }
    });
  }
  calculateTotalAmount(): void {
    this.totalAmount = 0;
  
    // Add user's seat price if the user is also a passenger
    if (this.isUserAlsoPassenger && this.userSeatNumber) {
      const seat = this.seatList.find(s => s.seatNumber === this.userSeatNumber);
      if (seat) {
        this.totalAmount += seat.seatPrice;
      }
    }
  
    // Add each additional passenger's seat price
    this.passengers.forEach(passenger => {
      if (passenger.pSeatNumber) {
        const seat = this.seatList.find(s => s.seatNumber === passenger.pSeatNumber);
        if (seat) {
          this.totalAmount += seat.seatPrice;
        }
      }
    });
  
    console.log("Total amount calculated:", this.totalAmount);
  }
  
  proceedToPayment(): void {
    this.calculateTotalAmount();
    this.showPaymentSection = true; // or whatever you use to toggle the payment section
  }
  
  
  processPayment() {
    // Check if required fields are filled and if a seat is selected
    if (this.paymentMethod === "debitCard" && (!this.cardNumber || !this.cvv || !this.cardExpiry)) {
      alert("Please fill in all the card details.");
      return; // Exit the function if card details are missing
    }
  
    if (this.paymentMethod === "upi" && !this.upiId) {
      alert("Please enter your UPI ID.");
      return; // Exit the function if UPI ID is missing
    }
  
    if (!this.isSeatSelected) {
      alert("Please select a seat.");
      return; // Exit the function if no seat is selected
    }
  
    const paymentId = 'PAY' + Date.now(); // Generate payment ID like "PAY(CURRENT TIME IN MILLISECONDS)"
    
    const onPaymentSuccess = () => {
      this.submitPassengers(paymentId); // ✅ Only submit after payment is successful
    };
  
    // Proceed with payment based on the payment method
    if (this.paymentMethod === "debitCard") {
      this.bankService.getCardDetailsbyCNumCVVD(this.cardNumber, this.cvv, this.cardExpiry).subscribe(
        (response) => {
          if (response == null) {
            alert("Card details not found");
          } else {
            alert("Payment Successful!");
            onPaymentSuccess(); // ✅ Trigger passenger submission
          }
        },
        error => {
          console.error("Payment failed", error);
          alert("Payment failed.");
        }
      );
    }
  
    if (this.paymentMethod === "upi") {
      this.bankService.getUpi(this.upiId).subscribe(
        (response) => {
          if (response == null) {
            alert("UPI ID does not exist");
          } else {
            alert("Payment Successful!");
            onPaymentSuccess(); // ✅ Trigger passenger submission
          }
        },
        error => {
          console.error("Payment failed", error);
          alert("Payment failed.");
        }
      );
    }
  }
  
  
}