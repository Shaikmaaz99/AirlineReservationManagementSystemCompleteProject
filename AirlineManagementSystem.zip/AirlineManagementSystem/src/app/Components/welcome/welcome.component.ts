import { Component, OnInit } from '@angular/core';
import { LoginvalidationService } from '../../Services/loginvalidation.service';
import { User } from '../../Model/User';
import { Router } from '@angular/router';

@Component({
  selector: 'app-welcome',
  standalone: false,
  templateUrl: './welcome.component.html',
  styleUrl: './welcome.component.css'
})
export class WelcomeComponent implements OnInit{
  constructor(private loginvalidationService:LoginvalidationService,private router:Router){}
  user=new User();
  userId:any;
  ngOnInit(): void {
    
  }
  loginUser() {
    if (!this.user.userEmail || !this.user.userPassword) {
      alert("YOU CANNOT LEAVE USERNAME OR PASSWORD AS EMPTY");
      return;
    }
  
    this.loginvalidationService.loginvalidation(this.user).subscribe(
      (response: any) => {
        if (response == null) {
          alert("USERNAME OR PASSWORD IS INCORRECT");
        } else {
          this.userId = Object.values(response)[0];
          console.log(this.userId);
          sessionStorage.setItem('userId', this.userId);
          sessionStorage.setItem('userFirstName', response.userFirstName);
          sessionStorage.setItem('userLastName', response.userLastName);
          alert("Login Successfully");
          this.router.navigate(['home']);
        }
      },
      (error) => {
        alert("Login failed, try again");
        console.error(error);
      }
    );
  }
  
    forgotpassword(){
      this.router.navigate(['forgotpassword']);

  }
  createaccount(){
    this.router.navigate(['createaccount']);

  }
}
