import { Flight } from "./Flight";
import { Passenger } from "./Passenger";
import { Reservation } from "./Reservation";

export interface Booking {
    reservation: Reservation // Include the Reservation class as a field
    flight: Flight;
    passengers: Passenger[];
  }