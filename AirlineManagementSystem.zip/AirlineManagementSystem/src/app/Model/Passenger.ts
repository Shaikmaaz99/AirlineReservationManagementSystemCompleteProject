import { Reservation } from "./Reservation";
import { User } from "./User";

export class Passenger{
    pId:number |null;
    pFirstName:string;
    pLastName:string;
    pEmail:string;
    pMobileNo:string;
    pPassportNo:string;
    pAge:number;
    pGender:string;
    pSeatNumber:string;
    user?:User;
    pflightId:number;
    pPaymentId:string;
    reservation?:Reservation;
    constructor(){
        this.pId=null;
        this.pFirstName="";
        this.pLastName="";
        this.pEmail="";
        this.pMobileNo="";
        this.pPassportNo="";
        this.pAge=0;
        this.pGender="";
        this.pSeatNumber=""
        this.pflightId=0;
        this.pPaymentId="";
    }
}