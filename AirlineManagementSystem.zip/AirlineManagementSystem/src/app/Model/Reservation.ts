export class Reservation{
    rId:number |null;
    bookingDate:string;
    journeyDate:string;
    rStatus:string;
    rsource:string;
    rdestination:string;
    amount:number;
    reservationStatus: string;
    reservationNumber:string;
    constructor(){
        this.rId=null;
        this.bookingDate="";
        this.journeyDate="";
        this.rStatus="";
        this.rsource="";
        this.rdestination="";
        this.amount=0;
        this.reservationStatus="";
        this.reservationNumber="";
    }

}