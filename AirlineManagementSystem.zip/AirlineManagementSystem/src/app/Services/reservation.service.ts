import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ReservationService implements OnInit{
  ngOnInit(): void {
    
  }
url="http://localhost:8089/api/Reservation"
  constructor(private httpClient:HttpClient) { }

  getTheBookingDetailsByUserId(userId:any){
    return this.httpClient.get(`${this.url}/by-user-id/${userId}`)
  }
 cancleReservation(reservationNumber:any){
  return this.httpClient.put(`${this.url}/cancel/${reservationNumber}`,{})
 }

}